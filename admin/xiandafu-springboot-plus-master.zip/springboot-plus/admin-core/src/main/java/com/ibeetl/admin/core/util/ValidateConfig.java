package com.ibeetl.admin.core.util;

public class ValidateConfig {
	public interface ADD {
	}

	public interface UPDATE {
	}
}
