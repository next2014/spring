package com.ibeetl.admin.core.util;

public class ExcelError {
   
    String cell;
    String msg;
  
  
    public String getCell() {
        return cell;
    }
    public void setCell(String cell) {
        this.cell = cell;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
   
    
    
}
