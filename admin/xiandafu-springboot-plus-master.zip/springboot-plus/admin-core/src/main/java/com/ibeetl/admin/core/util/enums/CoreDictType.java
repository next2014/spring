package com.ibeetl.admin.core.util.enums;

/**
 * @author : xiandafu
 */
public class CoreDictType {
    
   public static final  String ORG_TYPE="org_type";
   public static final  String USER_STATE="user_state";
   public static final  String DEL_FLAG="del_flag";
   public static final  String ROLE_TYPE="role_type";
   public static final  String MENU_TYPE="menu_type";
   public static final  String FUNCTION_TYPE="function_type";
  
    
}
