package com.ibeetl.admin.core.gen.model;

/**
 * 添加表单属性的校验
 */
public class Verify {

	private String name;//校验规则名称

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
