package com.ibeetl.admin.core.util.doc;

import java.util.Map;

import org.jxls.expression.ExpressionEvaluator;

public class BeetlExpressionEvaluator implements ExpressionEvaluator{

    @Override
    public Object evaluate(String expression, Map<String, Object> context) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object evaluate(Map<String, Object> context) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getExpression() {
        // TODO Auto-generated method stub
        return null;
    }

}
