/* tslint:disable:no-unused-variable */

import { TestBed, async } from "@angular/core/testing";
import { AppComponent } from "./app.component";

describe("App: Angular2BootstrapSass", () => {

});
