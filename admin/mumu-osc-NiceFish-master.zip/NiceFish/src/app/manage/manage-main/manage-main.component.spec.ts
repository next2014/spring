/* tslint:disable:no-unused-variable */

import { TestBed, async } from "@angular/core/testing";
import { ManageMainComponent } from "./manage-main.component";

describe("Component: ManageMain", () => {

});
