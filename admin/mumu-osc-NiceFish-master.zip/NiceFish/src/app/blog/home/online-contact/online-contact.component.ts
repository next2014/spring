import { Component, OnInit } from "@angular/core";

@Component({
  selector: "online-contact",
  templateUrl: "./online-contact.component.html",
  styleUrls: ["./online-contact.component.scss"]
})
export class OnlineContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
