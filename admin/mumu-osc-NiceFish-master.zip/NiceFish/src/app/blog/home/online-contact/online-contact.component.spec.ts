/* tslint:disable:no-unused-variable */

import { TestBed, async } from "@angular/core/testing";
import { OnlineContactComponent } from "./online-contact.component";

describe("Component: OnlineContact", () => {

});
