import { Component, OnInit } from "@angular/core";

@Component({
  selector: "post-headline",
  templateUrl: "./post-headline.component.html",
  styleUrls: ["./post-headline.component.scss"]
})
export class PostHeadlineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
