import { WritePostComponent } from "../write-post/write-post.component";

export const writePostRoutes = [
    {
        path: "",
        component: WritePostComponent
    }
];
