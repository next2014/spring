/* tslint:disable:no-unused-variable */

import { TestBed, async } from "@angular/core/testing";
import { SignUpComponent } from "./sign-up.component";

describe("Component: SignUp", () => {

});
