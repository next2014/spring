/* tslint:disable:no-unused-variable */

import { TestBed, async } from "@angular/core/testing";
import { UserInfoComponent } from "./user-info.component";

describe("Component: UserInfo", () => {

});
