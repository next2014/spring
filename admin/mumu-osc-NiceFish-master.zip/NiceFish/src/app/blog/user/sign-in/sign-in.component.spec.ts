/* tslint:disable:no-unused-variable */

import { TestBed, async } from "@angular/core/testing";
import { SignInComponent } from "./sign-in.component";

describe("Component: UserLogin", () => {

});
