package com.mallplus.member.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mallplus.member.entity.SysSchool;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zscat
 * @since 2019-04-14
 */
public interface SysSchoolMapper extends BaseMapper<SysSchool> {

}
