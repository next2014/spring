package com.mallplus.member.config;

import com.central.common.config.DefaultPasswordConfig;
import org.springframework.context.annotation.Configuration;

/**
 * @author mall
 * @date 2019/1/2
 */
@Configuration
public class PasswordConfig extends DefaultPasswordConfig {
}
