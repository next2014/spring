package com.mallplus.member.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mallplus.member.entity.SysArea;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zscat
 * @since 2019-04-14
 */
public interface SysAreaMapper extends BaseMapper<SysArea> {

}
