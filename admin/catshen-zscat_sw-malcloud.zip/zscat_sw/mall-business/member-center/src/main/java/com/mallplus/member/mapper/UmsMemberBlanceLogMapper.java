package com.mallplus.member.mapper;

import com.mallplus.member.entity.UmsMemberBlanceLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zscat
 * @since 2019-04-19
 */
public interface UmsMemberBlanceLogMapper extends BaseMapper<UmsMemberBlanceLog> {

}
