package com.mallplus.member.utils;

import com.fasterxml.jackson.annotation.JsonFilter;

@JsonFilter("propertyFilterMixIn")
public class PropertyFilterMixIn {

}
