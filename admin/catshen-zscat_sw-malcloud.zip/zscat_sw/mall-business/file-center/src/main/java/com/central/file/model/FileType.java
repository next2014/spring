package com.central.file.model;

/**
 * 仅支持阿里云 oss ,七牛云等
 *
 * @author 作者 mallplus E-mail: 951449465@qq.com
 */
public enum FileType {
    //七牛
    QINIU,
    //阿里云
    ALIYUN
}
