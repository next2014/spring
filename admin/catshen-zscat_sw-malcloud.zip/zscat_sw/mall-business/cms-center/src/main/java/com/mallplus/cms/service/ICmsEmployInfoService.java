package com.mallplus.cms.service;

import com.mallplus.cms.entity.CmsEmployInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zscat
 * @since 2019-04-28
 */
public interface ICmsEmployInfoService extends IService<CmsEmployInfo> {

}
