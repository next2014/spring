package com.mallplus.cms.mapper;

import com.mallplus.cms.entity.CmsParter;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zscat
 * @since 2019-04-28
 */
public interface CmsParterMapper extends BaseMapper<CmsParter> {

}
