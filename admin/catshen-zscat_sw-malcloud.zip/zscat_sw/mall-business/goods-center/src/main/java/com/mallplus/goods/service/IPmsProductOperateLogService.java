package com.mallplus.goods.service;

import com.mallplus.goods.entity.PmsProductOperateLog;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author zscat
 * @since 2019-04-19
 */
public interface IPmsProductOperateLogService extends IService<PmsProductOperateLog> {

}
