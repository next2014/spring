package com.mallplus.goods.service;

import com.mallplus.goods.entity.PmsFeightTemplate;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 运费模版 服务类
 * </p>
 *
 * @author zscat
 * @since 2019-04-19
 */
public interface IPmsFeightTemplateService extends IService<PmsFeightTemplate> {

}
