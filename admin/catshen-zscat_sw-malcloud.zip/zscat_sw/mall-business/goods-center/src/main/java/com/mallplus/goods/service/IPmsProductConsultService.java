package com.mallplus.goods.service;

import com.mallplus.goods.entity.PmsProductConsult;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 产品咨询表 服务类
 * </p>
 *
 * @author zscat
 * @since 2019-04-19
 */
public interface IPmsProductConsultService extends IService<PmsProductConsult> {

}
