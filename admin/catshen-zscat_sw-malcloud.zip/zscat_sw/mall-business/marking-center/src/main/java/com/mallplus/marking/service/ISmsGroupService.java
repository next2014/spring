package com.mallplus.marking.service;

import com.mallplus.marking.entity.SmsGroup;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author zscat
 * @since 2019-04-19
 */
public interface ISmsGroupService extends IService<SmsGroup> {

}
