<template>
  <div>
    <h1>
      工资表查询
    </h1>
  </div>
</template>
